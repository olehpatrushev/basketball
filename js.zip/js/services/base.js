export class BaseService {
    app = null

    constructor(app) {
        this.app = app
    }
}